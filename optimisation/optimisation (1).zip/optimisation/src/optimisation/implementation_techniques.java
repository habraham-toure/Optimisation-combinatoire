package optimisation;

import java.util.ArrayList;
import java.util.HashSet;


public class implementation_techniques {


	public static void main(String[] args){
		// TODO Auto-generated method stub
		
		
// ************************************ DATA (Générateur Aléatoire) ************************************
		
		// nous avons implémenté un générateur aléatoire qui génère des valeurs différentes dès qu'on lance le code; de ce faite les résultas de nos méthode sont à chaque fois différentes
		
		double encarts = 50;             // nombre d'encart total
		double revues = 15;              // nombre de revue total
		double cout_depassement = 6;     // cout de dépassement par zone
		double dispo_nomi_revue = 100;   // disponibilité nominale d'une revue en nombre de zone
		double depassement_zone = 20;    // dépassement en nombre de zone
	
		
		System.out.println("===================================================================================== DATA (Generateur Aleatoire) =====================================================================================");
	    System.out.println("\nLe nombre d'encarts est: "+encarts);
	    System.out.println("Le nombre de revues est: "+revues);
	    System.out.println("Le coût de dépassement pour chaque zone est: "+cout_depassement+" k euros/zone");
	    System.out.println("La disponibilité nominale d'une revue est: "+dispo_nomi_revue+" zones (5pages)");
	    System.out.println("Le dépassement en nombre de zones est: "+depassement_zone+" zones");
	       

        System.out.println("\n-Voici l'encombrement des encarts généré aléatoirement: ");
	    double[] encombrement_encarts = new double[50];    // encombrement des encarts ~U(5,20)zones
		double min = 5;
		double max = 20;
		
		for(int a=0 ;a<50; a++) {
			encombrement_encarts[a] = min + (int)(Math.random()*(max - min +1));  // utilisation de la méthode Math.random() pour générer des nombres aléatoires
			System.out.print(encombrement_encarts[a]+" "); 
		}
		
		System.out.println("");
	    System.out.println("\n-Voici les revenus générés aléatoirement: ");
	    double[][] valeurs = new double [15][50];         // revenus ~U(7,27)k€
		double min_rev = 7;
		double max_rev = 27;
		
		for(int b=0; b<15; b++) {
			for(int c=0; c<50; c++) {
			valeurs[b][c] = min_rev + (int)(Math.random()*(max_rev - min_rev +1));  // utilisation de la méthode Math.random() pour générer des nombres aléatoires 
			System.out.print(valeurs[b][c]+" "); 
		}
			System.out.println();
		}
		
		System.out.println("");
		System.out.println("===================================================================================== FIN DATA =====================================================================================");

		System.out.println("");
		System.out.println("\n************************************************************************************** HEURISTIQUE: Methode Gloutonnes **************************************************************************************");  
		System.out.println("");
		Heuristique_Glouton(encombrement_encarts,valeurs);
		
		System.out.println("\n************************************************************************************** META-HEURISTIQUE: Recuit Simulé **************************************************************************************");
		Metaheuristique_Recuit_Simule(encombrement_encarts,valeurs);

	}		
		
	
  private static void Heuristique_Glouton(double[] encombrement, double[][] valeurs) {    // nous avons codé ici notre méthode Gloutonne proposée lors de l'étape 2 du projet

			double dispo_nomi_revue = 100;    // disponibilité nominale d'une revue en nombre de zone
			double cout_depassement = 6;      // coût de dépassement par zone
			double depassement_zone = 20;     // dépassement en nombre de zone
			double dep = 0;
			double new_val = 0;
			ArrayList<Double> sol = new ArrayList<Double>();  // on crée une ArrayList dans lequel on mettra les solutions obtenues au fur et à mesure
			
			// on définit le prix pour chaque zone des 50 encarts 
			double[][] prix = new double[15][50];  
			
			for(int a=0; a<15; a++){
	       	 for(int b=0; b<50; b++)         
	            prix[a][b] = Double.parseDouble(String.format("%.4s",valeurs[a][b]/encombrement[b]));    // on arrondi au 100ème les valeurs

	       	 }
			
			for(int i=0; i<15; i++) {
				for(int j=0; j<50; j++) {
				
				System.out.print(prix[i][j]+" "); 
			}
				System.out.println(); 
			}
			
			int count = 0;      // on initialise un compteur à 0 ppur pouvoir faire notre incrémentation plus tard
			
			// ici, on cherche à sélectionner le plus grand profit(ici le prix) dû à l'affectation de la revue i à l'encart j
			do {
				double max = 7;
				int colonne_max = 0;   // on initialise la colonne à 0 au début
				int ligne_max = 0;     // on initialise la ligne à 0 au début
				
				for (int i=0; i<15; i++){
					for (int j=0; j<50; j++){
						if (prix[i][j] > max){
							max = prix[i][j];
							ligne_max = i;
							colonne_max = j;
						}
					}
				}
				
				//première condition si: s'il n'y a pas d'autres valeurs occupées dans la colonne alors on peut ajouter notre début de solution
				
				boolean occup_1 = false;
				boolean occup_2 = false;
				
				for (int x=0; x<15; x++){
					
					if(prix[x][colonne_max] == 0)
						occup_1 = true;
				}
			
				//deuxième condition si: si la capacité de la revue - la zone d'encart est >=0 alors on peut ajouter notre début de solution
				
				if(occup_1 == false && occup_2 == false) {   // on vérifie qu'aucune valeur n'est occupée dans la zone
					
					if(dispo_nomi_revue-encombrement[colonne_max] >= 0) {   // on vérifie que la capacité de la revue - la zone d'encart étudié est bien >= 0
						sol.add(valeurs[ligne_max][colonne_max]);   // si cela est le cas alors on ajoute notre solution (sol) dans notre ArrayList contenant nos solutions
						dispo_nomi_revue = dispo_nomi_revue-encombrement[colonne_max];    // on met à jour la disponibilité nominale de la revue car nous avons utilisé un emplacement dans la revue en question
						new_val = new_val+valeurs[ligne_max][colonne_max];	// notre variable new_val est mise à jour 			
					
					// sinon si le nombre de dépassement + l'encombrement de l'encart étudié est <= dépassement de la zone (20)
					}else {
						if(dep+encombrement[colonne_max] <= depassement_zone) {
							
						sol.add(valeurs[ligne_max][colonne_max]);   // on ajoute notre début de solution dans notre ArrayList de solution
						dispo_nomi_revue = dispo_nomi_revue-encombrement[colonne_max];  // on met aussi à jour 
						dep = dep+encombrement[colonne_max];    // on calcule la valeur du dépassement
						new_val = new_val+valeurs[ligne_max][colonne_max];   // on calcule la valeur de la nouvelle solution obtenue
		       }
		   }
       }
			    // On cherche le plus grand prix possible pour les 50 encarts
				prix[ligne_max][colonne_max] = 0;
				count++;   // on incrémente le compteur jusqu'à 50
			}
			   while(count!=50);  // fin de la boucle tant que
			
			
			    double profit = new_val-dep - cout_depassement; // on calcule ici le profit qui représente le gain en k€ généré avec notre heuristique
			    System.out.println("");                                                
				System.out.println("\nLa valeur de la somme des solutions présentent dans notre tableau de solutions est: "+new_val);
				System.out.println("Le depassement est: "+dep+ " zone(s)");
				System.out.println("---Le profit généré par notre méthode gloutonne est: "+profit+" k euros");
		}			
	
				

  private static void Metaheuristique_Recuit_Simule(double[] encombrement, double[][] valeur) {  // nous avons codé ici notre méta-heuristique du Recuit Simulé proposée lors de l'étape 2 du projet
	  
	    double depassement_zone = 20;     // dépassement en nombre de zone
		double cout_depassement = 6;      // coût de dépassement par zone
		double dispo_nomi_revue = 100;    // disponibilité nominale d'une revue en nombre de zone
		double temp_max = 500;            // température initiale Tmax
		double perf = 0;
		double p = 80;    // choix arbitraire
		double perte_depassement = 0;
		double new_perte_depassement = 0;
		double resultat = 0;    // résultat initialisé à 0 au début
		ArrayList<Integer> ligne_actuelle = new ArrayList<Integer>();  // on créé une ArrayList pour stocker les valeurs des lignes étudiées
		HashSet<Integer> colonne_actuelle = new HashSet<Integer>();    // on créé une liste avec HashSet pour ne pas autoriser les doublons et ne pas avoir d'ordre
		ArrayList<Double> revenu = new ArrayList<Double>();    // on créé une ArrayList pour stocker les valeurs des revenues des colonnes et des lignes
		HashSet<Integer> derniere_col = new HashSet<Integer>(); // on créé une liste avec HashSet pour ne pas autoriser les doublons et ne pas avoir d'ordre
		ArrayList<Integer> derniere_ligne = new ArrayList<Integer>();   // on crée une liste pour stocker les dernières lignes parcourues
		randomSet(1,50,15,derniere_col);   // on utilise une méthode défini par la suite pour générer des ensembles aléatoires
		
		 for (int a=0; a<15; a++) {  
			 int number = (int) (Math.random() * 14)+1;  // on génère un nombre aléatoirement avec la méthode Math.random()
			 derniere_ligne.add(number); 
		}  	 
	
		 ArrayList<Integer> derniere_colonne = new ArrayList<Integer>(derniere_col);
		 
		 
		 // on commence par initialiser la liste
		 for (int i = 0; i < 13; i++) { 
			 
			 // on ajoute ensuite les lignes et les colonnes
			 int ligne;
			 int colonne;
			 ligne = derniere_ligne.get(i);    // la variable ligne prend la valeur de chaque élément de la liste derniere_ligne
			 colonne = derniere_colonne.get(i);   // la variable colonne prend la valeur de chaque élément de la liste derniere_colonne
			 
			 if(dispo_nomi_revue-encombrement[colonne] >= 0) {   // disponibilité nominale de chaque revue de la colonne étudiée doit être positif
				 revenu.add(valeur[ligne][colonne]);             // si cette condition est vérifiée alors on ajoute la valeur dans notre tableau des revenus
				 dispo_nomi_revue=dispo_nomi_revue-encombrement[colonne];   // on met ensuit à jour la valeur de la disponibilité nominale de la revue en la soustrayant à l'encombrement de la colonne en question
			 }else if(depassement_zone+encombrement[colonne] <= 20) {   // si le dépassement de la zone + son encombrement est < 20
				 revenu.add(valeur[ligne][colonne]);     // on ajoute dans le tableau des revenus la valeur 
				 dispo_nomi_revue=dispo_nomi_revue-encombrement[colonne];  // on met également à jour la disponibilité nominale de la revue 
				 depassement_zone=depassement_zone+encombrement[colonne];  // on met aussi à jour le dépassement 
			 }else
				
				 break;    // on met un break pour ne parcourir qu'une seule fois la boucle
		      }   
		 
		 System.out.println("-Valeurs des revenus(k euros): ");   
		 for (int y=0; y<revenu.size(); y++) {
			 System.out.println("Revenu: "+revenu.get(y));    // on affiche le revenu obtenu pour chaque élément de notre tableau de revenu 
			 perte_depassement = perte_depassement+revenu.get(y); // on estime la perte liée aux dépassements
		 }
		 
		 System.out.println("\n-La perte liée aux dépassements de zones est: "+(perte_depassement-depassement_zone*cout_depassement)+"k euros");    // On calcule la perte liée aux dépassements de zones en fonction de leurs coûts de dépassements
		 System.out.println("\n-Valeurs des nouveaux revenus calculés(k euros):");
		 
		 double depassement_ZONE = 20;
		 double dispo_NOMI_REVUE = 100;

		 do {
		 ligne_actuelle.clear();     // ici, on utilise la méthode clear() afin de supprimer tous les éléments de notre liste d'entier, liste_actuelle est donc maintenant vide
		 colonne_actuelle.clear(); // ici, on utlise aussi la méthode clear() pour vider notre liste d'entier
			
		 
			// on cherche et test les voisinages pour chaque itération
			 for(int n=0; n<13; n++) {	
				 int ligne;
				 int colonne;
				 
				 ligne = derniere_ligne.get(n);    // on récupère les 13 éléments de notre liste d'entier de derniere_ligne
			     colonne = derniere_colonne.get(n);  // on récupère les 13 éléments de notre liste d'entier de derniere_colonne
				
				
				int nouvelle_ligne = neighborhood(ligne,14);    // on fait appel à la fonction neighborhood que l'on défini après pour pouvoir essayer de trouver des voisins dans notre nouvelle ligne
				int nouvelle_colonne = neighborhood(colonne,49);    // on fait appel à la fonction neighborhood pour essayer de trouver des voisins dans notre nouvelle colonne
				 
				
				ligne_actuelle.add(nouvelle_ligne);    // on ajoute à notre liste ligne_actuelle la valeur de notre nouvelle_ligne obtenue
				colonne_actuelle.add(nouvelle_colonne);   // on ajoute à notre liste colonne_actuelle_ la valeur de la nouvelle colonne obtenue
			 }
			   revenu.clear();  // on supprime les éléments de notre liste revenu
			 
			   
			   
			     ArrayList<Integer> colonne_actuelle2 = new ArrayList<Integer>(derniere_col); 
			    
			 for (int k=0; k<13; k++) {  
				 int ligne;
				 int colonne;
				 
				 ligne = ligne_actuelle.get(k);     // on récupère la valeur de notre ligne_actuelle
				 colonne = colonne_actuelle2.get(k);   // on récupère la valeur de notre colonne_actuelle
				 
				 if(dispo_NOMI_REVUE - encombrement[colonne] >= 0) {   // on vérifie que la disponibilité nominale de la revue - l'encombrement de la colonne étudiée est bien positif
					 revenu.add(valeur[ligne][colonne]);  // si cela est le cas, alors on ajoute dans notre liste revenu la valeur en question
					 dispo_NOMI_REVUE = dispo_NOMI_REVUE-encombrement[colonne];  // il faut également remettre à jour la disponibilité nominale de la revue qui à changée
				 }
				 
				 else if(depassement_ZONE + encombrement[colonne]<=20) {    // sinon quand le dépassement de zone + son encombrement est inférieure à 20 
					 revenu.add(valeur[ligne][colonne]);   // on ajoute dans notre liste revenu cette nouvelle valeur 
					 dispo_NOMI_REVUE = dispo_NOMI_REVUE - encombrement[colonne];  // on doit aussi remettre à jour la disponibilité nominale de cette revue
					 depassement_ZONE = depassement_ZONE + encombrement[colonne];  // on calcule également son dépassement en zone
				 }	 
			     }
			
			 
			 
			 for (int m=0; m<revenu.size(); m++) {  	// on incrémente la valeur de m justqu'à la taille de la liste de revenu 
				 
				 System.out.println("Revenu: "+revenu.get(m)+" ");  // on affiche les valeurs des nouveaux revenus obtenus 
				
				 new_perte_depassement = new_perte_depassement + revenu.get(m);
			 }
		 
			 
			 if(new_perte_depassement > perte_depassement) {  // on regarde si la nouvelle perte de dépassement est supérieure à l'ancienne perte de dépassement
				 perf = new_perte_depassement;   // si cela est bien le acs alors on met à jour la valeur
				 new_perte_depassement = perte_depassement;
	
			 }
			 else if(((int) (Math.random() * 100)) < p){   // on utilise Math.random() * 100 pour retourner un nombre aléatoire entre 0 et 99 et inférieure à p que l'on a fixé à 80
				 perf = new_perte_depassement;
				 new_perte_depassement = perte_depassement;
				 p = p * 0.8;  // on fixe un pourcentage à 80 % (arbitraire)
			 }
			 
			   temp_max = temp_max * 0.8-1;  // on calcule à nouveau la température max 
		 }
		 
		 while(temp_max > 0);
		 resultat = perf;
		 
		    System.out.println("\n-Resultat: "+resultat+"k euros");
		    System.out.println("\n-Le depassement est: "+depassement_ZONE+" zone(s)");
		    System.out.println("\n-La perte liée aux dépassements est: "+resultat+"k euros");
		    System.out.println("\n-Profit: "+(resultat-depassement_ZONE*cout_depassement+"k euros"));
			System.out.println("\n---Le meilleur profit généré par notre méthode du recuit simulé est: "+(resultat-depassement_zone*cout_depassement)+"k euros");
}
	
  
  public static void randomSet(int min, int max, int x, HashSet<Integer> set) {   // méthode pour générer des ensembles aléatoirement
		
	  for (int i=0; i<x; i++) {
			int number = (int) (Math.random() * (max - min+1)) + min;
			set.add(number);
		  }
		
		int setSize = set.size();
		if (setSize < x) {
			randomSet(min, max, x - setSize, set);
		  }
		  }
  
  
	public static int neighborhood(int number,int max) {   // méthode nous permettant de chercher si il y a des voisins et les déterminer
		
		int ancienne_valeur = number;
		if((int) (Math.random() * 2) == 1)
			number = (int) (number + Math.random() * 2);
		else
			number = (int) (number - Math.random() * 2);
	
		if(number> 0 && number<max) {
			
			return number;
			}
		else {
			return ancienne_valeur;
			}
	        }
}


/* ********************************************************** Borne supérieure Lagrangienne: Algorithme du sous-gradient **********************************************************

        private static void Borne_Sup_Lagrangienne() {      Nous avons essayé (sans réussir) de coder notre borne lagrangienne (UB3) déterminée lors de l'étape 3 du projet
		 int iter = 0;
		 int imax = 10;
		 int (c_tilde) ;
		 int (p_tilde);
		 int p = 2;
		 double alpha = 0,9;
		 int lamda = 0;
		 int z;
		 int cd;
		 int Y;
		 int (z_tilde);
		 int L_de_lamda;
		 int (L_etoile) = 10*100;
		 int y_barre;
		
		 (p_tilde_k) = (cd_k) - lamda_k; //calcul des couts régularisés
		
		 ((C-tilde)_j)^k = C_j_k - lamda_k * p_j
				 Maximazie(((C-tilde)_j)^k * (Y_j)^k)
				 for(int k = 1; k <= R; k++ ) {for(int j = 1; j <= E; j++ ) {(y_j)^k = 1}
						 (((C-tilde)_j)^k * (Y_j)^k).MAXIMIZE()
		
		
		 // Calcul de la fonction duale
		 private static void L(int lamda)
						 {
							 {
			 int result;
			 int result1 = 0;
			 int result2 = 0;
			 for(int j = 0; j <= E; j++ ) {
				 for(int k = 0; k <= R; k++ ) {
					 for(int j1 = 0; j1 <= E; j1++ ) {
						 for(int k1 = 0; k1 <= R; k1++ ) {
							 result1 = result1 + ( (c_tilde_j)^k * ((y_barre_j)^k) * lamda );
						 }
					 }
				 }
			 }
			 for(int k = 0; k<= R; k++) {
				 result2 = (Y_k) * (z_tilde_k) * lamba;
			 }
			 
			 result = result1 + result2;
			 return result;
			 
		 }
				(z_k) <= d_p_k)
				(((p_tilde)_k)* (z_k)).MINIMIZE() }
		 
		 //Sauvegarde de l'optimum dual courant
		 L_de_lamda = L(lamda);
		 
		 if(L_de_lamda < (L_etoile)) {
			 (L_etoile) = L_de_lamda;
			 
		 }
		 
		 // Calcul des composantes du sous-gradient
		 for(int k = 1; k <= R; k++ ) {
		 (Y_k) = (y_j)^k - (z_k) - 1;}
		 
		 
		 //Mise à jour des multiplicateur
		 private static void Y_carre(){
			 int result = 0;
			 for(int k = 0; k<= R; k++) {
				 result = result + ((Y_k) * (Y_k));
			 }
			 return result;
		 }
		 
		 int UB;
		 int y_carre = Y_;
		 lamda_k = lamda_k + (Y_k) * ((UB) - L_de_lamda) * (1/y_pow(2));
		 
		 // incrementer iter 
		 // Révision de p
		 
		 //j appartient à E et k à appartient R
		  
	}
*/













